<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Invoice <?php echo e($invoice->series); ?> <?php echo e($invoice->number); ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: DejaVu Sans, sans-serif; font-size: 12px; line-height: 1.4; padding: 40px; }
        .header { text-align: center; margin-bottom: 30px; }
        .header h1 { font-size: 24px; text-decoration: underline; margin-bottom: 10px; }
        .header .invoice-number { font-size: 14px; margin-bottom: 5px; }
        .header .invoice-date { font-size: 12px; }
        .parties { display: table; width: 100%; margin-bottom: 30px; border: 1px solid #000; }
        .party { display: table-cell; width: 50%; padding: 15px; vertical-align: top; }
        .party:first-child { border-right: 1px solid #000; }
        .party h3 { font-size: 14px; margin-bottom: 10px; text-align: center; }
        .party p { margin-bottom: 5px; }
        table.items { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        table.items th, table.items td { border: 1px solid #000; padding: 8px; text-align: left; }
        table.items th { background: #f0f0f0; }
        table.items .number { width: 50px; text-align: center; }
        table.items .unit { width: 60px; text-align: center; }
        table.items .qty { width: 60px; text-align: center; }
        table.items .price { width: 80px; text-align: right; }
        table.items .total { width: 80px; text-align: right; }
        .grand-total { text-align: right; font-size: 14px; font-weight: bold; margin-bottom: 30px; }
        .notes { margin-bottom: 30px; }
        .signatures { margin-top: 50px; }
        .signature-line { border-top: 1px solid #000; margin-top: 40px; padding-top: 5px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>SĄSKAITA FAKTŪRA</h1>
        <div class="invoice-number">Serija <?php echo e($invoice->series); ?> Nr. <?php echo e(str_pad($invoice->number, 7, '0', STR_PAD_LEFT)); ?></div>
        <div class="invoice-date"><?php echo e($invoice->invoice_date->format('Y')); ?> m. <?php echo e($invoice->invoice_date->translatedFormat('F')); ?> <?php echo e($invoice->invoice_date->format('d')); ?> d.</div>
    </div>

    <div class="parties">
        <div class="party">
            <h3>Pardavėjo rekvizitai</h3>
            <p><strong><?php echo e($invoice->user->name); ?></strong></p>
            <?php if($invoice->user->company_code): ?>
                <p>Įmonės kodas / IV pažyma: <?php echo e($invoice->user->company_code); ?></p>
            <?php endif; ?>
            <?php if($invoice->user->vat_code): ?>
                <p>PVM kodas: <?php echo e($invoice->user->vat_code); ?></p>
            <?php endif; ?>
            <?php if($invoice->user->address): ?>
                <p>Adresas: <?php echo e($invoice->user->address); ?></p>
            <?php endif; ?>
            <?php if($invoice->user->phone): ?>
                <p>Telefonas: <?php echo e($invoice->user->phone); ?></p>
            <?php endif; ?>
            <?php if($invoice->user->email): ?>
                <p>El. paštas: <?php echo e($invoice->user->email); ?></p>
            <?php endif; ?>
            <?php if($invoice->user->website): ?>
                <p>Svetainė: <?php echo e($invoice->user->website); ?></p>
            <?php endif; ?>
            <?php if($invoice->user->bank_name): ?>
                <p><?php echo e($invoice->user->bank_name); ?></p>
            <?php endif; ?>
            <?php if($invoice->user->bank_account): ?>
                <p>A/s: <?php echo e($invoice->user->bank_account); ?></p>
            <?php endif; ?>
        </div>
        <div class="party">
            <h3>Pirkėjo rekvizitai</h3>
            <p><strong><?php echo e($invoice->client->name); ?></strong></p>
            <?php if($invoice->client->company_code): ?>
                <p>Įmonės kodas / Asmens kodas: <?php echo e($invoice->client->company_code); ?></p>
            <?php endif; ?>
            <?php if($invoice->client->vat_code): ?>
                <p>PVM kodas: <?php echo e($invoice->client->vat_code); ?></p>
            <?php endif; ?>
            <?php if($invoice->client->address): ?>
                <p>Adresas: <?php echo e($invoice->client->address); ?></p>
            <?php endif; ?>
            <?php if($invoice->client->phone): ?>
                <p>Telefonas: <?php echo e($invoice->client->phone); ?></p>
            <?php endif; ?>
            <?php if($invoice->client->email): ?>
                <p>El. paštas: <?php echo e($invoice->client->email); ?></p>
            <?php endif; ?>
        </div>
    </div>

    <table class="items">
        <thead>
            <tr>
                <th class="number">Eil. Nr.</th>
                <th>Prekės ar paslaugos pavadinimas</th>
                <th class="unit">Mato vnt.</th>
                <th class="qty">Kiekis</th>
                <th class="price">Kaina, EUR</th>
                <th class="total">Suma, EUR</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="number"><?php echo e($index + 1); ?>.</td>
                <td><?php echo e($item->description); ?></td>
                <td class="unit"><?php echo e($item->unit); ?></td>
                <td class="qty"><?php echo e($item->quantity); ?></td>
                <td class="price"><?php echo e(number_format($item->price, 2)); ?></td>
                <td class="total"><?php echo e(number_format($item->total, 2)); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="grand-total">
        Iš viso: <?php echo e(number_format($invoice->total, 2)); ?> EUR
    </div>

    <div class="notes">
        <p>Sąskaitą apmokėti iki: <?php echo e($invoice->due_date->format('Y')); ?> <?php echo e($invoice->due_date->translatedFormat('F')); ?> <?php echo e($invoice->due_date->format('d')); ?> d.</p>
        <?php if($invoice->notes): ?>
            <p>Papildoma informacija: <?php echo e($invoice->notes); ?></p>
        <?php endif; ?>
    </div>

    <div class="signatures">
        <div class="signature-line">
            Sąskaitą išrašė: <?php echo e($invoice->user->name); ?>

        </div>
        <div class="signature-line">
            Sąskaitą priėmė: _______________________________________________
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\wamp64\www\exercises\invoice\invoice-api\resources\views/invoice.blade.php ENDPATH**/ ?>